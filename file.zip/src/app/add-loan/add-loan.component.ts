import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-loan',
  standalone: true, // Mark this as a standalone component
  templateUrl: './add-loan.component.html',
  styleUrls: ['./add-loan.component.css'],
  imports: [CommonModule, ReactiveFormsModule], // Import necessary modules
})
export class AddLoanComponent implements OnInit {
  loanForm: FormGroup;
  // Ensure this property is declared and accessible
  customers = [
    { id: 1, name: 'John Doe' },
    { id: 2, name: 'Jane Smith' },
    { id: 3, name: 'Mark Johnson' },
    // Add more customers as needed
  ];

  constructor(private fb: FormBuilder) {
    this.loanForm = this.fb.group({
      customer: ['', Validators.required],
      loanNumber: ['', [Validators.required, Validators.minLength(10)]],
      loanType: ['', Validators.required],
      loanAmount: ['', [Validators.required, Validators.min(1000)]],
    });
  }

  ngOnInit(): void {}

  onSubmit(): void {
    if (this.loanForm.valid) {
      console.log('Loan Details:', this.loanForm.value);
    }
  }
}
