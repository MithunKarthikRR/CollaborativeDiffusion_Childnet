import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms'; 
import { HttpClient, HttpClientModule } from '@angular/common/http'; 
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-add-card',
  templateUrl: './add-card.component.html',
  styleUrls: ['./add-card.component.css'],
  standalone: true, 
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule] 
})
export class AddCardComponent implements OnInit {
  cardForm!: FormGroup; // Use definite assignment assertion

  // Ensure this property is declared and accessible
  customers = [
    { id: 1, name: 'John Doe' },
    { id: 2, name: 'Jane Smith' },
    { id: 3, name: 'Mark Johnson' },
    // Add more customers as needed
  ];

  constructor(private fb: FormBuilder, private http: HttpClient) {}

  ngOnInit(): void {
    this.cardForm = this.fb.group({
      customer: ['', Validators.required],
      cardNumber: ['', [Validators.required, Validators.minLength(16), Validators.maxLength(16)]],
      cardType: ['', Validators.required],
      maxLimit: ['', [Validators.required, Validators.min(1000)]],
    });
  }

  onSubmit(): void {
    if (this.cardForm.valid) {
            console.log('Card added successfully');
    }
  }
}
