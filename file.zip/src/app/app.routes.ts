import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AddLoanComponent } from './add-loan/add-loan.component';
import { AddCardComponent } from './add-card/add-card.component';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'add-loan', component: AddLoanComponent },
  { path: 'add-card', component: AddCardComponent },
  { path: '**', redirectTo: 'dashboard' }, // Redirect any unknown paths to dashboard
];
